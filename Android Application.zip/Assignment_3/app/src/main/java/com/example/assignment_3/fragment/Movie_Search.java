package com.example.assignment_3.fragment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import com.example.assignment_3.movies;
import com.example.assignment_3.adapter_search;
import com.example.assignment_3.viewMovie;
import com.example.assignment_3.R;
import com.example.assignment_3.search_api;
import java.util.ArrayList;
import static android.content.Context.MODE_PRIVATE;


public class Movie_Search extends Fragment {
    Button button_search;
    ArrayList<movies> ar_movie;
    ListView vlist;
    adapter_search adapt;
    View v;
    search_api api;
    EditText moviesearch;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
         v = inflater.inflate(R.layout.movie_search, container, false);
        button_search = (Button)v.findViewById(R.id.button_search);
         moviesearch = (EditText)v.findViewById(R.id.moviesearch);

         button_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final String keyword = moviesearch.getText().toString(); //create an anonymous AsyncTask
                new AsyncTask<String, Void, String>() {
                    @Override
                    protected String doInBackground(String... params) {
                        return api.search(keyword, new String[]{"num"},
                                new String[]{"7"}); }
                    @Override
                    protected void onPostExecute(String result) {
                        vlist = (ListView)v.findViewById(R.id.search_list);
                        ar_movie = search_api.getSnippet(result);
                        adapt = new adapter_search(getActivity(),ar_movie);
                        vlist.setAdapter(adapt);
                        vlist.setClickable(true);
                        vlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                            @Override
                            public void onItemClick(AdapterView<?> arg0, View arg1, int position, long arg3) {

                                 Intent in = new Intent(getContext(), viewMovie.class);
                                movies present_movies = ar_movie.get(position);
                                 in.putExtra("decription", present_movies.getmdata());
                                in.putExtra("movieratings", present_movies.getrating());
                                in.putExtra("movietitles", present_movies.getmovie());

                                SharedPreferences sharedPreferences
                                        = getActivity().getSharedPreferences("website",
                                        MODE_PRIVATE);
                                SharedPreferences.Editor myEdit
                                        = sharedPreferences.edit();
                                myEdit.putString("image", present_movies.getmBitmapurl());
                                myEdit.commit();
                                 startActivity(in);
                            }
                        });
                    } }.execute();
                } });
        return v;
    }





}
