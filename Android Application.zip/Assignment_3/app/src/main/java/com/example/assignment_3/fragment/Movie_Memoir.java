package com.example.assignment_3.fragment;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;

import androidx.fragment.app.Fragment;

import com.example.assignment_3.adapter_memoir;
import com.example.assignment_3.R;
import com.example.assignment_3.networkconnection.RestClient;
import com.example.assignment_3.oreilly.servlet.multipart.MovieMemoir;

import java.util.ArrayList;


public class Movie_Memoir extends Fragment {
    View view1 ;
    Button sorting;
    Spinner spinner;
    RestClient restClient;
    adapter_memoir adaptermemoir;
    ListView list;
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the View for this fragment
        view1 = inflater.inflate(R.layout.movie_memoir, container, false);
        sorting = (Button)view1.findViewById(R.id.sort);
        spinner = (Spinner)view1.findViewById(R.id.sorting) ;
        list = (ListView)view1.findViewById(R.id.movlist);
        restClient = new RestClient();


        AddStudentTask addStudentTask = new AddStudentTask();
        addStudentTask.execute("");







        return view1;
    }

    private class AddStudentTask extends AsyncTask<String, Void, ArrayList<MovieMemoir>> {
        @Override
        protected ArrayList<MovieMemoir> doInBackground(String... params) {

            return restClient.getMemoirDetails();
        }
        @Override
        protected void onPostExecute(ArrayList<MovieMemoir> result) {
           // MovieMemoir m = result.get(0);
            //Log.d("Movieresult",m.getMovieName());
            adaptermemoir = new adapter_memoir(getActivity(),result);
            list.setAdapter(adaptermemoir);



            //  Toast.makeText(PieChart.this,"Data Added"+result,Toast.LENGTH_SHORT).show();
        }
    }
}
