package com.example.assignment_3.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.assignment_3.BarGraph;
import com.example.assignment_3.pieChart;
import com.example.assignment_3.R;

public class Report extends Fragment {
    View v;
    Button barGraph;
    Button pieChart;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.report, container, false);
        pieChart = (Button)v.findViewById(R.id.pie);
        barGraph = (Button)v.findViewById(R.id.bar);
        pieChart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(getContext(), pieChart.class);
                startActivity(intent);
            }
        });

        barGraph.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(getContext(), BarGraph.class);
                startActivity(intent);
            }
        });
    return v;
    }
}
