package com.example.assignment_3;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.assignment_3.database.watchDB;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class viewMovie extends AppCompatActivity {

    TextView m_list;
    watchDB wat;
    RatingBar ratings;
    Button add_m,add_w;
    String finals="";
    String head;
    Date dat;
    float d=0;
    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.movieview);

        wat = new watchDB(getApplicationContext());
        wat = wat.open();

        m_list = (TextView)findViewById(R.id.m_list);
        ratings = (RatingBar)findViewById(R.id.ratings);

        add_w = (Button)findViewById(R.id.add_w);
        add_m = (Button)findViewById(R.id.add_m);
        Bundle bun = getIntent().getExtras();

        String s = bun.getString("decription");
        String s1 = bun.getString("movieratings");
        head = bun.getString("movietitles");
        m_list.setText(s);
        if(s1!=null) {
             d = Float.parseFloat(s1);
        }
        ratings.setBackgroundColor(R.color.colorAccent);
        ratings.setNumStars(5);
        d = (d/2) ;
        ratings.setRating(d);
        add_w.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //date datatype is instanciated by using calender class
                dat = Calendar.getInstance().getTime();
                SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                String formattedDate = df.format(dat);
                int a= wat.checkentry(head);
                //check and toast the required ones
                if(a==0){
                    finals = wat.insert(head,formattedDate);
                    Toast.makeText(viewMovie.this,"Added to WatchList",Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(viewMovie.this,"Already Exist",Toast.LENGTH_SHORT).show();
                }
            }
        });

        add_m.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(viewMovie.this, add_memoir.class);
                intent.putExtra("abcd",head);
                startActivity(intent);
            }
        });
    }
}
