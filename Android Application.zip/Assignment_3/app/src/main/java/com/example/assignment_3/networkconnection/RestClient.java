package com.example.assignment_3.networkconnection;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import android.graphics.Bitmap;
import android.util.Log;
import com.example.assignment_3.userAdd;
import com.example.assignment_3.bar_sum;
import com.example.assignment_3.movies;
import com.example.assignment_3.pie_sum;
import com.example.assignment_3.oreilly.servlet.multipart.MovieMemoir;
import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonObject;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;

public class RestClient {
    String password = "";
    int check = 0;
    String name;
    String personId="";
    String user = "";
    private OkHttpClient okclient=null;
    private String answer;
    public static final MediaType JSON =
            MediaType.parse("application/json; charset=utf-8");
    public RestClient(){
        okclient=new OkHttpClient();
    }
    private static final String BASE_URL = "http://192.168.1.107:8080/Assignment1/webresources/";
    public int findEmailAndPass(String email, String passw) {
        final String methodPath = "ass.credentials/findByUsername/"+email;
        Request.Builder builder = new Request.Builder(); builder.url(BASE_URL + methodPath);
        Request request = builder.build();
        try {
            Log.d("abc",passw);
            Response response = okclient.newCall(request).execute();
            answer=response.body().string();
            JSONArray jsonResponse = new JSONArray(answer);
            for (int i = 0; i < jsonResponse.length(); i++) {
                Object obj = jsonResponse.get(i);
                if(obj instanceof JSONObject) {

                    JSONObject object = jsonResponse.getJSONObject(i);
                    password = object.getString("password");
                    Log.d("paww",password);
                    user = object.getString("username");
                    Log.d("uder",user);

                    if(user.compareTo(email)==0){
                        check = 1;
                        break;
                    }
                }
            }
            Log.d("aaa",""+answer);
        }catch (Exception e){ e.printStackTrace();
        }
        Log.d("fdfdfdfd",""+check);
        return check;
       }

    public String getme(String email) {
        final String methodPath = "ass.credentials/findByUsername/"+email;

        Request.Builder builder = new Request.Builder(); builder.url(BASE_URL + methodPath);
        Request request = builder.build();
        try {
            Response response = okclient.newCall(request).execute();
            answer=response.body().string();
            JSONArray jsonResponse = new JSONArray(answer);

            for (int i = 0; i < jsonResponse.length(); i++) {
                Object obj = jsonResponse.get(i);
                if(obj instanceof JSONObject) {
                    JSONObject object = jsonResponse.getJSONObject(i);
                    JSONObject object1 = object.getJSONObject("personId");
                    name = object1.getString("firstName");
                }
            }
            Log.d("aab",name);
        }catch (Exception e){ e.printStackTrace();
        }
        return name;
    }

    public ArrayList<movies> getus(String email) {
        final String methodPath = "ass.credentials/findByUsername/"+email;
        int pid;
        ArrayList<movies> moviesList = new ArrayList<>();
        Request.Builder builder = new Request.Builder(); builder.url(BASE_URL + methodPath);
        Request request = builder.build();
        try {
            //Log.d("abc",okclient.toString());
            Response response = okclient.newCall(request).execute();
            answer=response.body().string();
            JSONArray jsonResponse = new JSONArray(answer);

            //data.clear();
            for (int i = 0; i < jsonResponse.length(); i++) {
                Object obj = jsonResponse.get(i);
                if(obj instanceof JSONObject) {
                    JSONObject object = jsonResponse.getJSONObject(i);
                    JSONObject object1 = object.getJSONObject("pid");
                    pid = Integer.parseInt(object1.getString("personId"));
                    moviesList = getMovies(pid);
                }
            }
            Log.d("aaa",""+answer);
        }catch (Exception e){ e.printStackTrace();
        }
        return moviesList;
    }

    public ArrayList<movies> getMovies(int pid) {
        final String methodPath = "ass.memoir/task4f/"+pid;
        ArrayList<movies> moviesList = new ArrayList<>();
        Request.Builder builder = new Request.Builder(); builder.url(BASE_URL + methodPath);
        Request request = builder.build();
        try {
            //Log.d("abc",okclient.toString());
            Response response = okclient.newCall(request).execute();
            answer=response.body().string();
            JSONArray jsonResponse = new JSONArray(answer);
            //data.clear();
            for (int i = 0; i < jsonResponse.length(); i++) {
                Object obj = jsonResponse.get(i);
                if(obj instanceof JSONObject) {
                    JSONObject object = jsonResponse.getJSONObject(i);
                    Bitmap b=null;
                    moviesList.add(new movies( object.getString("movieName") ,object.getString("score"), b,object.getString("release_date")));
                }
            }
            Log.d("aaa",""+answer);
        }catch (Exception e){ e.printStackTrace();
        }
        return moviesList;
    }



    public String addData(String[] details) {
        Gson gson = new Gson();
        JsonObject ob1=new JsonObject();
        try {
            ob1.addProperty("password",details[0]);
            JsonObject ob2 =new JsonObject();
            ob2.addProperty("address",details[1]);
            ob2.addProperty("statename",details[2]);
            ob2.addProperty("dob",details[3]);
            ob2.addProperty("firstName",details[4]);
            ob2.addProperty("gender",details[5]);
            ob2.addProperty("personId",Integer.parseInt(details[6]));
            ob2.addProperty("postcode",Integer.parseInt(details[7]));
            ob2.addProperty("surname",details[8]);
            ob1.add("personId",ob2);
            ob1.addProperty("signupDate",details[9]);
            ob1.addProperty("userId",details[10]);
            ob1.addProperty("username",details[11]);

        } catch (JsonIOException e) {
            e.printStackTrace();
        }
        String studentJson = gson.toJson(ob1);
        Log.d("Test",studentJson);
        String strResponse="";
        final String methodPath = "ass.credentials";
        RequestBody body = RequestBody.create(studentJson, JSON);
        Request request = new Request.Builder()
                .url(BASE_URL + methodPath) .post(body)
                .build();
        try {
            Response response= okclient.newCall(request).execute();
            strResponse= response.body().string();
        } catch (Exception e) {
            e.printStackTrace();
        }
        Log.d("Test",strResponse);
        return strResponse;
    }

    public String addMovie(String[] details) {
        //AddUser user = new AddUser(details[0], details[1],details[2],details[3],details[4],details[5],details[6],details[7],details[8],details[9],details[10],details[11]);
        String personobj[] = userName(details[6]);
        Log.d("Person",personobj[0]);
        Gson gson = new Gson();
        JsonObject ob1=new JsonObject();
        try {
           // ob1.addProperty("cinemaId",details[0]);
            JsonObject ob2 =new JsonObject();
            ob2.addProperty("cinemaId",details[9]);
            ob2.addProperty("cinemaName",details[0]);
            ob2.addProperty("location",details[1]);
            ob1.add("cinemaId",ob2);
            ob1.addProperty("userComment",details[2]);
            ob1.addProperty("watchedDate",details[3]);
            ob1.addProperty("memoirId",Integer.parseInt(details[4]));
            ob1.addProperty("movieName",details[5]);
            ob1.addProperty("releaseDate",details[10]);
           // ob1.add("personId",ob2);
            JsonObject ob3 =new JsonObject();
            ob3.addProperty("address",personobj[0]);
            ob3.addProperty("statename",personobj[1]);
            ob3.addProperty("dob",personobj[2]);
            ob3.addProperty("firstName",personobj[3]);
            ob3.addProperty("gender",personobj[4]);
            ob3.addProperty("personId",personobj[5]);
            ob3.addProperty("postcode",personobj[6]);
            ob3.addProperty("surname",personobj[7]);
            ob1.add("personId",ob3);
            ob1.addProperty("score",details[7]);
            ob1.addProperty("watchedTime",details[8]);
        } catch (JsonIOException e) {
            e.printStackTrace();
        }
        String studentJson = gson.toJson(ob1);
        Log.d("Test",studentJson);
        String strResponse="";
        final String methodPath = "ass.memoir";
        RequestBody body = RequestBody.create(studentJson, JSON);
        Request request = new Request.Builder()
                .url(BASE_URL + methodPath) .post(body)
                .build();
        try {
            Response response= okclient.newCall(request).execute();
            strResponse= response.body().string();
        } catch (Exception e) {
            e.printStackTrace();
        }
        Log.d("Test",strResponse);
        return strResponse;
    }


    public String addCinema(String[] details) {
        Gson gson = new Gson();
        JsonObject ob1=new JsonObject();
        try {
            ob1.addProperty("cinemaId",Integer.parseInt(details[0]));
            ob1.addProperty("cinemaName",details[1]);
            ob1.addProperty("location",details[2]);
        } catch (JsonIOException e) {
            e.printStackTrace();
        }
        String studentJson = gson.toJson(ob1);
        Log.d("Test",studentJson);
        String strResponse="";
        final String methodPath = "ass.cinema";
        RequestBody body = RequestBody.create(studentJson, JSON);
        Request request = new Request.Builder()
                .url(BASE_URL + methodPath) .post(body)
                .build();
        try {
            Response response= okclient.newCall(request).execute();
            strResponse= response.body().string();
        } catch (Exception e) {
            e.printStackTrace();
        }
        Log.d("Test",strResponse);
        return strResponse;
    }

    public String[] userName(String name) {
        String personObj[]=new String[20];
        Log.d("NSSS",name);
        final String methodPath = "ass.person/findByFirstName/"+name;
        Request.Builder builder = new Request.Builder(); builder.url(BASE_URL + methodPath);
        Request request = builder.build();
        try {
            Response response = okclient.newCall(request).execute();
            answer=response.body().string();
            JSONArray jsonResponse = new JSONArray(answer);
            Log.d("PEron",jsonResponse.toString());
            for (int i = 0; i < jsonResponse.length(); i++) {
                Object obj = jsonResponse.get(i);
                if(obj instanceof JSONObject) {
                    JSONObject object = jsonResponse.getJSONObject(i);
                    String address = object.getString("address");
                    String state = object.getString("statename");
                    String dateOfBirth = object.getString("dob");
                    String firstName = object.getString("firstName");
                    String gender = object.getString("gender");
                    String personId =  object.getString("personId");
                    String postcode = object.getString("postcode");
                    String surname = object.getString("surname");
                    personObj[0] = address;
                    personObj[1] = state;
                    personObj[2] = dateOfBirth;
                    personObj[3] = firstName;
                    personObj[4] = gender;
                    personObj[5] = personId;
                    personObj[6] = postcode;
                    personObj[7] = surname;
                }
            }
            Log.d("mdmdmdmddd",personObj[5]);
        }catch (Exception e){ e.printStackTrace();
        }
        return personObj;
    }

    public ArrayList<pie_sum> getPieCount(int pid, String start, String end) {
        final String methodPath = "ass.memoir/task4a/"+pid+"/"+start+"/"+end;
        ArrayList<pie_sum> pielist = new ArrayList<>();
        Request.Builder builder = new Request.Builder(); builder.url(BASE_URL + methodPath);
        Request request = builder.build();
        try {
            //Log.d("abc",okclient.toString());
            Response response = okclient.newCall(request).execute();
            answer=response.body().string();
            JSONArray jsonResponse = new JSONArray(answer);
            //data.clear();
            for (int i = 0; i < jsonResponse.length(); i++) {
                Object obj = jsonResponse.get(i);
                if(obj instanceof JSONObject) {
                    JSONObject object = jsonResponse.getJSONObject(i);
                    pielist.add(new pie_sum(Integer.parseInt(object.getString("count")),Integer.parseInt(object.getString("location"))));
                }
            }
            Log.d("aaa",""+answer);
        }catch (Exception e){ e.printStackTrace();
        }
        return pielist;
    }

    public ArrayList<bar_sum> getBarCount(int pid, String year) {
        final String methodPath = "ass.memoir/task4b/"+pid+"/"+year;
        ArrayList<bar_sum> barsums = new ArrayList<>();
        Request.Builder builder = new Request.Builder(); builder.url(BASE_URL + methodPath);
        Request request = builder.build();
        try {
            //Log.d("abc",okclient.toString());
            Response response = okclient.newCall(request).execute();
            answer=response.body().string();
            JSONArray jsonResponse = new JSONArray(answer);
            //data.clear();
            for (int i = 0; i < jsonResponse.length(); i++) {
                Object obj = jsonResponse.get(i);
                if(obj instanceof JSONObject) {
                    JSONObject object = jsonResponse.getJSONObject(i);
                    barsums.add(new bar_sum(Integer.parseInt(object.getString("count")),object.getString("months")));
                }
            }
            Log.d("aaa",""+answer);
        }catch (Exception e){ e.printStackTrace();
        }
        return barsums;
    }

    public ArrayList<MovieMemoir> getMemoirDetails() {
        final String methodPath = "ass.memoir";
        ArrayList<MovieMemoir> movieMemoirs = new ArrayList<>();
        Request.Builder builder = new Request.Builder();
        builder.url(BASE_URL + methodPath);
        Request request = builder.build();
        try {
            Log.d("abc",okclient.toString());
            Response response = okclient.newCall(request).execute();
            answer=response.body().string();
            Log.d("abcksks",answer);
            JSONArray jsonResponse2 = new JSONArray(answer);
            //data.clear();
            for (int i = 0; i < jsonResponse2.length(); i++) {
                Object obj = jsonResponse2.get(i);
                if(obj instanceof JSONObject) {
                    JSONObject object = jsonResponse2.getJSONObject(i);
                    Log.d("abcdef",object.toString());
                    String comm = object.getString("userComment");
                    String datewatch = object.getString("watchedDate");
                    String mName = object.getString("movieName");
                    String mReleaseDate = object.getString("releaseDate");
                    String mrating = object.getString("score");
                    String timeWatch = object.getString("watchedTime");
                    JSONObject object1 = object.getJSONObject("cinemaId");
                    String postcode = object1.getString("location");
                    movieMemoirs.add(new MovieMemoir(mName,comm,datewatch,mReleaseDate,mrating,postcode,timeWatch));
                }
            }
            Log.d("hdhhdhdhdhdh",""+answer);
        }catch (Exception e){ e.printStackTrace();
        }
        return movieMemoirs;
    }
}

