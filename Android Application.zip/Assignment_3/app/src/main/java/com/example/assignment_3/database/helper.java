package com.example.assignment_3.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


public class helper extends SQLiteOpenHelper {
    public helper(Context con, String name, CursorFactory fact, int v) {
        super(con, name, fact, v);
    }
    // Called to create if no table exists.
    @Override
    public void onCreate(SQLiteDatabase _db) {
        try {
            _db.execSQL(watchDB.DATABASE_CREATE);
        }catch(Exception e){
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase _db, int _oldVersion, int _newVersion)
    {
        // Delete old table if it exists.
        _db.execSQL("DROP TABLE IF EXISTS " + "watchlist");
        // To create a new table if its exists.
        onCreate(_db);
    }
}

