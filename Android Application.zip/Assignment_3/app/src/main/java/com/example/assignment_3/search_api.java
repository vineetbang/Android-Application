package com.example.assignment_3;

import android.graphics.Bitmap;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

public class search_api {

    private static final String API_KEY = "AIzaSyBBpzr-PncbeUjDTfml2nbcYUGmOb9ywmA";
    private static final String SEARCH_ID_cx = "005336693554333672851:1dzsaotmotx";
    public static String search(String keyword, String[] params, String[] values) {
        keyword = keyword.replace(" ", "+");
        URL site = null;
        HttpURLConnection connection = null;
        String answer="";
        String param = "";
        if (params != null && values != null) {
            for (int i = 0; i < params.length; i++) {
                param += "&";
                param += params[i];
                param += "=";
                param += values[i];
            }
        }
        try {
            site = new URL("https://www.googleapis.com/customsearch/v1?key=" + API_KEY + "&cx=" +
                    SEARCH_ID_cx + "&q=" + keyword + param);
            connection = (HttpURLConnection) site.openConnection();
            connection.setReadTimeout(10000);
            connection.setConnectTimeout(15000);
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("Accept", "application/json");
            Scanner scanner = new Scanner(connection.getInputStream());
            int count = 0;
            while (scanner.hasNextLine()) {
                answer+= scanner.nextLine();
                count++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            connection.disconnect();
        }
        return answer;
    }
    
    public static ArrayList<movies> getSnippet(String result){
        String snip = "";
        ArrayList<movies> moviesList = new ArrayList<>();
        String search = "";
        try{
            JSONObject jobj = new JSONObject(result);
            JSONArray jarr = jobj.getJSONArray("items");
            if(jarr != null && jarr.length() > 0) {
                for(int i = 0;i< jarr.length();i++) {
                    snip = jarr.getJSONObject(i).getString("title");
                    search = jarr.getJSONObject(i).getString("snippet");
                    String sr = jarr.getJSONObject(i).getString("pagemap");
                    JSONObject t1 = new JSONObject(sr);
                    JSONArray jarr1 = t1.getJSONArray("cse_image");
                    JSONArray jarr3 = t1.getJSONArray("metatags");
                    String finals = jarr3.getJSONObject(0).getString("og:description");
                    String sss = jarr1.getJSONObject(0).getString("src");
                    JSONArray jarr2 = t1.getJSONArray("aggregaterating");
                    String sss2 = jarr2.getJSONObject(0).getString("ratingvalue");
                    moviesList.add(new movies(snip,sss,finals,sss2));
                }
            }
        }catch (Exception e){ e.printStackTrace();
            snip = "NO DATA FOUND";
        }
        return moviesList;
    }
}

