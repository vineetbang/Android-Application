package com.example.assignment_3;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class adapter_search extends ArrayAdapter<movies> {


    private Context con;
    Bitmap b = null;
    ImageView image;
    private ArrayList<movies> mlist = new ArrayList<>();

    public adapter_search(@NonNull Context context, @SuppressLint("SupportAnnotationUsage") @LayoutRes ArrayList<movies> list) {
        super(context, 0 ,list);
        con = context;
        mlist = list;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItem = convertView;
        if (listItem == null)
            listItem = LayoutInflater.from(con).inflate(R.layout.movie_search_list, parent, false);
// movie search using Async task by assigning all parts
        movies currentMovies = mlist.get(position);
        image = (ImageView)listItem.findViewById(R.id.imageView2);
        new RetrieveFeedTask().execute(currentMovies.getmBitmapurl());
        TextView name = (TextView) listItem.findViewById(R.id.name);
        name.setText(currentMovies.getmovie());
        return listItem;
    }

    class RetrieveFeedTask extends AsyncTask<String, Void, Bitmap> {
        private Exception exception;
        protected Bitmap doInBackground(String...urll) {
            try {
                final Bitmap[] bit = {null};
                URL site = new URL(urll[0]);
                HttpURLConnection conn = (HttpURLConnection) site.openConnection();
                conn.setDoInput(true);
                conn.connect();
                InputStream input = conn.getInputStream();
                bit[0] = BitmapFactory.decodeStream(input);
                return bit[0];
            } catch (Exception e) {
                this.exception = e;
                return null;
            }
        }

        protected void onPostExecute(Bitmap bitf) {
            image.setImageBitmap(bitf);
        }
    }

    public Bitmap getBitmapFromURL(final String source) {

        final Bitmap[] bit = {null};
        Thread th = new Thread(new Runnable() {
            @Override
            public void run() {
                try  {
                    URL site = new URL(source);
                    HttpURLConnection conn = (HttpURLConnection) site.openConnection();
                    conn.setDoInput(true);
                    conn.connect();
                    InputStream input = conn.getInputStream();
                    bit[0] = BitmapFactory.decodeStream(input);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        th.start();
        return bit[0];
    }
}
