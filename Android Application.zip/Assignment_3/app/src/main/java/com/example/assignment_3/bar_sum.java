package com.example.assignment_3;

public class bar_sum {

    private int count;
    String months;
   public bar_sum(int count, String months){
        this.count=count;
        this.months=months;
    }

    public int getCount() {
        return count;
    }

    public String getMonths() {
        return months;
    }
}
