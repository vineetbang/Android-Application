package com.example.assignment_3;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.assignment_3.networkconnection.RestClient;

import java.io.Serializable;
import java.util.ArrayList;

public class add_cinema extends AppCompatActivity {


    EditText c_name,c_post;
    Button Add;
    int adder;
    SharedPreferences show;
    RestClient restClient;
    ArrayList<String> cinema_list;
    ArrayList<String> cinema_code;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_cinema);
        cinema_list = getIntent().getStringArrayListExtra("name");
        cinema_code = getIntent().getStringArrayListExtra("code");
        restClient = new RestClient();
        show = getSharedPreferences("MySharedPref",
                MODE_PRIVATE);
         adder = show.getInt("count", 106);
        c_name = (EditText)findViewById(R.id.c_name);
        c_post = (EditText)findViewById(R.id.c_post);
        Add = (Button) findViewById(R.id.add);
        Add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text = c_name.getText().toString();
                String post = c_post.getText().toString();
                String[] details = new String[3];
                details[0] = ""+adder;
                details[1] = text;
                details [2] = post;
                cinema_list.add(text);
                cinema_code.add(post);
                adder++;
                SharedPreferences.Editor myEdit
                        = show.edit();
                myEdit.putInt(
                        "count",adder);
                myEdit.commit();
                add_cinema.AddCinemaTask addCinemaTask = new AddCinemaTask();
                addCinemaTask.execute(details);
                Intent intent = new Intent(add_cinema.this, add_memoir.class);
                intent.putExtra("name", (Serializable) cinema_list);
                intent.putExtra("code", (Serializable) cinema_code);
                startActivity(intent);
            }
        });
    }

    private class AddCinemaTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {

            return restClient.addCinema(params) ;
        }
        @Override
        protected void onPostExecute(String result) {
            Toast.makeText(add_cinema.this,"Data Added in Database"+result,Toast.LENGTH_SHORT).show();
        }
    }
}
