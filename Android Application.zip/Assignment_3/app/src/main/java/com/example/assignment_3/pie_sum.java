package com.example.assignment_3;

public class pie_sum {

    private int count;
    private int postcode;

    public pie_sum(int count, int postcode){
        this.count=count;
        this.postcode=postcode;

    }

    public int getCount() {
        return count;
    }

    public int getPostcode() {
        return postcode;
    }
}
