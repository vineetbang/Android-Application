package com.example.assignment_3.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.widget.Toast;

public class watchDB {

    static final String DATABASE_NAME = "database.db";
    String ok="OK";
    static final int DATABASE_VERSION = 3;
    public static final int NAME_COLUMN = 1;

    // TODO: Create public field for each column in your table.
    // SQL Statement to create a new database.
    static final String DATABASE_CREATE = "create table watch( _id INTEGER PRIMARY KEY AUTOINCREMENT,NAME  text,ADDED_DATE  DATE); ";
    // Variable to hold the database instance
    public static SQLiteDatabase db;
    // Context of the application using the database.
    private final Context context;
    // Database open/upgrade helper
    private static helper dbHelper;


    public watchDB(Context _context)
    {
        context = _context;
        dbHelper = new helper(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    // Method to openthe Database
    public watchDB open() throws SQLException
    {
        db = dbHelper.getWritableDatabase();        return this;
    }
    // Method to close the Database
    public void close()
    {
        db.close();
    }
    // method returns an Instance of the Database
    public  SQLiteDatabase getDatabaseInstance()
    {
        return db;
    }
    // method to insert a record in Table
    public String insert(String moviename,String date)
    {
        try {
            ContentValues newValues = new ContentValues();
            // Assign values for each column.
            newValues.put("NAME", moviename);
            newValues.put("ADDED_DATE", date);

            // Insert the row into your table
            db = dbHelper.getWritableDatabase();
            long result=db.insert("watch", null, newValues);
            System.out.print(result);
            Toast.makeText(context, "Data saved in Watchlist", Toast.LENGTH_LONG).show();
        }catch(Exception ex) {
            System.out.println("Exceptions " +ex);
        }
        return ok;
    }

    // method to delete a Record of UserName
    public int deleteEntry(String mname)
    {
        String where="NAME=?";
        int numberOFEntriesDeleted= db.delete("watch", where, new String[]{mname}) ;
        Toast.makeText(context, "Deleted Successfully", Toast.LENGTH_LONG).show();
        return numberOFEntriesDeleted;
    }
    // method to get the password  of userName
    public Cursor getEntry()
    {
        db=dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT  * FROM watch", null);
        return cursor;
    }


    public int checkentry(String name)
    {
        db=dbHelper.getReadableDatabase();
        Cursor cursor = db.query("watchlist", new String[] {"MOVIENAME"},
                "MOVIENAME" + " LIKE ?", new String[] {"%" + name + "%"},
                null, null, null);
        if(cursor.getCount()<1)
            return 0;
        return 1;
    }
    // Method to Update an Existing
    public void  updateEntry(String userName,String password)
    {
        //  create object of ContentValues
        ContentValues updatedValues = new ContentValues();
        // Assign values for each Column.
        updatedValues.put("USERNAME", userName);
        updatedValues.put("PASSWORD", password);
        String where="USERNAME = ?";
        db.update("LOGIN",updatedValues, where, new String[]{userName});
    }

}