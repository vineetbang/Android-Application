package com.example.assignment_3.fragment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Spinner;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.example.assignment_3.activity_map;
import com.example.assignment_3.R;
import com.example.assignment_3.networkconnection.RestClient;
import static android.content.Context.MODE_PRIVATE;

public class Map extends Fragment {
    View v1;
    String present;
    RestClient client;
    String finaled[];
    Spinner spin;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v1 = inflater.inflate(R.layout.map, container, false);
        client = new RestClient();
        SharedPreferences sharedPreferences2
                = getActivity().getSharedPreferences("sharedName",
                MODE_PRIVATE);
        present = sharedPreferences2.getString("Firstname","");

        new AsyncTask<String, Void, String[]>() {
            @Override
            protected String[] doInBackground(String... params) {
                return client.userName(present); }
            @Override
            protected void onPostExecute(String[] result) {
                finaled = result;
            } }.execute();

        spin = (Spinner) v1.findViewById(R.id.lPostcode);
        Button but =v1.findViewById(R.id.user);
        but.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v1) {
                Log.d("abcd",finaled[0]);
                Intent in = new Intent(getContext(), activity_map.class);
                in.putExtra("location", finaled[0]);
                startActivity(in);
            } });

        Button cinemaButton = v1.findViewById(R.id.Butcinema);
        cinemaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v1) {
                Intent in = new Intent(getContext(), activity_map.class);
                in.putExtra("postcode",spin.getSelectedItem().toString());
                startActivity(in);
            }
        });
        return v1;
    }
}
