package com.example.assignment_3;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;

public class movies {
    private String movie;
    private String rating;
    private Bitmap image;
    private String saver;
    private String all;
    private String date;
    // Constructor that is used to create an instance of the Movie object
    
    public movies(String movie, String saver, String all, String rating ) {
        this.movie = movie;
        this.saver = saver;
        this.all = all;
        this.rating = rating;
    }
    public movies(String movie, String rating, Bitmap image, String rdate) {
        this.rating = rating;
        this.movie = movie;
        this.image = image;
        this.date = rdate;
    }
    
    public String getmRDate() {
        return date;
    }
    public String getrating() {
        return rating;
    }

    public void setrating(String rating) {
        this.rating = rating;
    }

    public String getmdata() {
        return all;
    }

    public String getmBitmapurl() {
        return saver;
    }

    public void setmBitampurl(String saver) {
        this.saver = saver;
    }

    public String getmovie() {
        return movie;
    }

    public void setmovie(String movie) {
        this.movie = movie;
    }


}
