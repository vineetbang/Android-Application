package com.example.assignment_3;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.assignment_3.oreilly.servlet.multipart.MovieMemoir;

import java.util.ArrayList;

public class adapter_memoir extends ArrayAdapter<movies> {
    private Context con;
    private ArrayList<MovieMemoir> list_mov = new ArrayList<>();

    public adapter_memoir(@NonNull Context context, @SuppressLint("SupportAnnotationUsage") @LayoutRes ArrayList<MovieMemoir> list) {
        super(context, 0 );
        con = context;
        list_mov = list;
    }

    @NonNull
    @Override
    public View getView(int pos, @Nullable View convert, @NonNull ViewGroup parent) {
        View listItem = convert;
        if (listItem == null)
            listItem = LayoutInflater.from(con).inflate(R.layout.memoir_list, parent, false);

        MovieMemoir currentMovie = list_mov.get(pos);
        TextView moviename = (TextView)listItem.findViewById(R.id.mname);
        moviename.setText(currentMovie.getMovieName());
        TextView releasedate = (TextView)listItem.findViewById(R.id.releaseDate);
        releasedate.setText(currentMovie.getMovieReleaseDate());
        TextView watchdate = (TextView)listItem.findViewById(R.id.watched);
        watchdate.setText(currentMovie.getDateWatch());
        TextView postcode = (TextView)listItem.findViewById(R.id.c_postcode);
        postcode.setText(currentMovie.getPostcode());
        TextView comment = (TextView)listItem.findViewById(R.id.comment);
        comment.setText(currentMovie.getComment());
        ImageView image;
        image = (ImageView)listItem.findViewById(R.id.image);
        RatingBar rating = (RatingBar)listItem.findViewById(R.id.rating);
        rating.setRating(Float.parseFloat(currentMovie.getRatingScore()));

        return listItem;
    }
}
