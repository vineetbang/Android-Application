package com.example.assignment_3;

public class userAdd {

    private String firstName, surname, dateOfBirth, address,state,postcode,gender,username, password,personId,userId,signupDate;
    public userAdd(String password , String address , String state , String dateOfBirth , String firstName, String gender, String personId , String postcode, String surname, String signupDate , String userId, String username )
    { this.password = password;
        this.address = address;
        this.state = state;
        this.dateOfBirth = dateOfBirth;
        this.firstName = firstName;
        this.gender=gender;
        this.personId = personId;
        this.postcode = postcode;
        this.surname = surname;
        this.signupDate = signupDate;
        this.userId = userId;
        this.username=username;

    }
}
