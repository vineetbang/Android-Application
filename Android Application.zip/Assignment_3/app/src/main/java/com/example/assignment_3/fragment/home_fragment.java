package com.example.assignment_3.fragment;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import com.example.assignment_3.home;
import com.example.assignment_3.movies;
import com.example.assignment_3.adapter_movie;
import com.example.assignment_3.R;
import com.example.assignment_3.networkconnection.RestClient;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import static android.content.Context.MODE_PRIVATE;
import static com.example.assignment_3.R.layout.*;

public class home_fragment extends Fragment {
    private TextView name, heading, date;
    RestClient client =null;
    String mail;
    private adapter_movie adapt;
    View v1;
    public home_fragment() {
// Required empty public constructor
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        home home = (home)getActivity();
        mail = home.getDate();
        client = new RestClient();
        v1 = inflater.inflate(home_fragment, container, false);
        name = v1.findViewById(R.id.name);
        heading = v1.findViewById(R.id.title);
        date = v1.findViewById(R.id.date);
        AsyncTaskMovie data = new AsyncTaskMovie();
        data.execute();
        Date dat = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
        String formattedDate = df.format(dat);
        date.setText(formattedDate);
        AsyncTaskU udata = new AsyncTaskU();
        udata.execute();
        return v1;
    }

    private class AsyncTaskU extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... params) {
            return client.getme(mail);
        }
        @Override
        protected void onPostExecute(String students) {
        name.setText(students);
            SharedPreferences sharedPreferences
                    = getActivity().getSharedPreferences("sharedName",
                    MODE_PRIVATE);
            SharedPreferences.Editor myEdit1
                    = sharedPreferences.edit();

            myEdit1.putString(
                    "Firstname",name.getText().toString());
            myEdit1.commit();
        }
    }

    private class AsyncTaskMovie extends AsyncTask<Void, Void, ArrayList<movies> > {
        @Override
        protected ArrayList<movies>  doInBackground(Void... params) {
            return client.getus(mail);
        }
        @Override
        protected void onPostExecute(ArrayList<movies> students) {
            ListView listView = (ListView)v1.findViewById(R.id.list);
            adapt = new adapter_movie(getActivity(),students);
            listView.setAdapter(adapt);
        }
    }
}