package com.example.assignment_3;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;

import com.example.assignment_3.database.watchDB;


public class adapter_watch extends CursorAdapter {

    watchDB wat;
    Context cont;
    String sr="";
    String d_added;

    public adapter_watch(Context context, Cursor c, int flags) {
        super(context, c, flags);
        this.cont = context;
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {

        View v = LayoutInflater.from(context).inflate(R.layout.watchlist_list, viewGroup, false);
        return v;
    }

    @Override
    public void bindView(View view, Context context, final Cursor cursor) {
        TextView title = (TextView)view.findViewById(R.id.title);
        TextView date = (TextView)view.findViewById(R.id.dates);
        wat =new watchDB(cont);
         sr = cursor.getString(cursor.getColumnIndexOrThrow("NAME"));
         d_added = cursor.getString(cursor.getColumnIndexOrThrow("ADDED_DATE"));
        title.setText(sr);
        date.setText(d_added);
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                  int a = wat.deleteEntry(sr);
            }
        });
    }
}
