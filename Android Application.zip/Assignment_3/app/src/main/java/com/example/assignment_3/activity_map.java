package com.example.assignment_3;

import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.List;

public class activity_map extends FragmentActivity implements OnMapReadyCallback {
    private GoogleMap m;
    private LatLng loc;
    LatLng loc3[];
    String locations="";
    Float col=0.0f;
    String temp="";
    String location,postcode;
    String dec="";
    @Override
    protected void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); setContentView(R.layout.activity_maps);
        Intent intent = getIntent();
        Geocoder coder = new Geocoder(this);
        List<Address> addr = null;
        loc3 = new LatLng[2];

                 location = intent.getExtras().getString("location");
                postcode = intent.getExtras().getString("postcode");
            if(postcode!=null) {
                if (postcode.compareTo("3185") == 0) {
                    dec = "3 oak ave";
                    temp = "Classic Cinemas";
                } else if (postcode.compareTo("3148") == 0) {
                    dec = "4 atkinson st";
                    temp = "Hoyts";
                } else if (postcode.compareTo("3800") == 0) {
                    dec = "13 scenic bkvl";
                    temp = "Cinema";
                } else if (postcode.compareTo("3186") == 0) {
                    dec = "11 lindsay st";
                    temp = "Palace Dendy Brighton";
                }
                else if (postcode.compareTo("3182") == 0) {
                    dec = "8 gurner st";
                    temp = "The Astor Theatre";
                }
                else if (postcode.compareTo("3185") == 0) {
                    dec = "5 redcliffs ave";
                    temp = "Barefoot Cinema";
                }
                else if (postcode.compareTo("3149") == 0) {
                    dec = "3 charlton st";
                    temp = "Waverley Cinema";
                }
                try {
                    addr = coder.getFromLocationName(dec, 5);
                } catch (IOException e){

                }
                locations = temp;
                col = BitmapDescriptorFactory.HUE_RED;
            } else if(location!=null) {
                try {
                    addr = coder.getFromLocationName(location, 5);
                } catch (IOException e){

                }
                locations=location;
                col=BitmapDescriptorFactory.HUE_GREEN;
            }
        Address locc=addr.get(0);
        double latitude = Double.parseDouble(String.valueOf(locc.getLatitude()));
        double longitude = Double.parseDouble(String.valueOf(locc.getLongitude()));
        loc = new LatLng(latitude, longitude);

// Obtain the SupportMapFragment and get notified when the map is ready to be
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map); mapFragment.getMapAsync(this);
    }
    @Override
    public void onMapReady(GoogleMap googleMap) {
        m = googleMap;

            m.addMarker(new MarkerOptions().icon(BitmapDescriptorFactory.defaultMarker(col)).position(loc).title(locations));


        float zoomLevel = (float) 10.0;
        m.moveCamera(CameraUpdateFactory.newLatLngZoom(loc, zoomLevel));
    } }