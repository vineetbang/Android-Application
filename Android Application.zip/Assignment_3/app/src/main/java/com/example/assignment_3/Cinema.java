package com.example.assignment_3;

public class Cinema {
    String name,code;
    Cinema(String name,String code){
        this.name = name;
        this.code= code;

    }

    public String getmname(){
        return name;
    }
    public String getCode(){
        return code;
    }
}
