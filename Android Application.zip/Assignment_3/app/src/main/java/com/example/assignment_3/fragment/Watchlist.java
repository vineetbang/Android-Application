package com.example.assignment_3.fragment;

import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.assignment_3.database.watchDB;
import com.example.assignment_3.R;
import com.example.assignment_3.adapter_watch;

public class Watchlist extends Fragment {
    View v;
    ListView lis;
    adapter_watch adapt;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.watchlist, container, false);

        lis = (ListView)v.findViewById(R.id.list_watched);
        watchDB handler = new watchDB(getActivity());
        Cursor cursor = handler.getEntry();
        adapt = new adapter_watch(getContext(),cursor,0);
        lis.setAdapter(adapt);

        lis.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

            }
        });
        return v;
    }
}
