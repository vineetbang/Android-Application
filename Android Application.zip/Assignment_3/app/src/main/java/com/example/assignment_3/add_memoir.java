package com.example.assignment_3;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.assignment_3.networkconnection.RestClient;

import java.io.InputStream;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class add_memoir extends AppCompatActivity {

    TextView m_name;
    Button add_cinema,add;
    EditText d_watch,t_watch,comment,rating;
    Spinner cinema_name, cinema_post_code;
    String temp = "";
    RestClient client;
    String dep;
    ImageView image;
    ArrayList<String> caller,sync;
    int s1;
    ArrayAdapter<String> adapt,adapt1;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_memoir);
        Bundle b =getIntent().getExtras();
        if(b!=null) {
            temp = b.getString("abcd");
        }
        //initializing variables
        client = new RestClient();
        rating = (EditText)findViewById(R.id.rating);
        image=(ImageView)findViewById(R.id.imageView3);
        cinema_name = (Spinner)findViewById(R.id.cinema_name);
        t_watch = (EditText)findViewById(R.id.t_watch);
        comment = (EditText)findViewById(R.id.comment);
        cinema_post_code = (Spinner)findViewById(R.id.cinema_post);
        add_cinema = (Button)findViewById(R.id.add_cinema);
        add = (Button)findViewById(R.id.add);
        m_name = (TextView)findViewById(R.id.m_name);
        d_watch = (EditText)findViewById(R.id.w_date);
        m_name.setText(temp);
        SharedPreferences sharedPreferences
                = getSharedPreferences("MySharedPref",
                MODE_PRIVATE);
        SharedPreferences.Editor myEdit
                = sharedPreferences.edit();

        SharedPreferences sharedPreferences1
                = getSharedPreferences("url",
                MODE_PRIVATE);
        String url = sharedPreferences1.getString("imageurl","");
        new RetrieveFeedTask().execute(url);
        s1 = sharedPreferences.getInt("count", 106);
        myEdit.putInt(
                "count",s1);
        myEdit.commit();
        SharedPreferences sharedPreferences2
                = getSharedPreferences("sharedName",
                MODE_PRIVATE);
         dep = sharedPreferences2.getString("Firstname","");
         
        final List<String> cinemaName = new ArrayList<String>();
        cinemaName.add("Classic Cinemas");
        cinemaName.add("Hoyts");
        cinemaName.add("Cinema");
        cinemaName.add("Palace Dendy Brighton");
        cinemaName.add("The Astor Theatre");
        cinemaName.add("Barefoot Cinema");
        cinemaName.add("Waverley Cinema");
        

        final List<String> postCode = new ArrayList<String>();
        postCode.add("3185");
        postCode.add("3148");
        postCode.add("3800");
        postCode.add("3186");
        postCode.add("3182");
        postCode.add("3185");
        postCode.add("3149");
        
        caller = getIntent().getStringArrayListExtra("name");
        sync = getIntent().getStringArrayListExtra("code");
        
        if(caller==null) {
            adapt = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, cinemaName);
        } else {
            adapt = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, caller);
        }

        if(sync==null) {
            adapt1 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, postCode);
        } else {
            adapt1 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, sync);
        }

        // Drop down layout style - list view with radio button
        adapt.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapt1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        cinema_name.setAdapter(adapt);
        cinema_post_code.setAdapter(adapt1);
        
        add_cinema.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(add_memoir.this, add_cinema.class);
                intent.putExtra("name", (Serializable) cinemaName);
                intent.putExtra("code", (Serializable) postCode);
                startActivity(intent);
            }
        });

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int rand = (int)(Math.random() * (200 - 100 + 1) + 100);
                String info[] =new String[20];
                String cName = cinema_name.getSelectedItem().toString();
                int pos = cinema_name.getSelectedItemPosition() + 101;
                String cpost = cinema_post_code.getSelectedItem().toString();
                String comments = comment.getText().toString();
                String dateWatch= d_watch.getText().toString();
                String memoirId = ""+rand;
                String movieName = temp;
                String releasedate = temp.substring(temp.indexOf("(")+1,temp.indexOf(")"));
                info[0] = cName;
                info[1] = cpost;
                info[2] = comments;
                info[3] =dateWatch+"T00:00:00+40:00";
                info[4] = memoirId;
                info[5] = movieName;
                info[10] = releasedate+"-05-05T12:04:20+10:00";
                info[6] = dep;
                info[7] = rating.getText().toString();
                info[8] = t_watch.getText().toString()+"T12:03:56+10:00";
                info[9] = ""+pos;
                add_memoir.task addStudentTask = new task();
                addStudentTask.execute(info);
            }
        });
    }

    private class task extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {

            return client.addMovie(params) ;
        }
        @Override
        protected void onPostExecute(String result) {
            Toast.makeText(add_memoir.this,"Data Added"+result,Toast.LENGTH_SHORT).show();
        }
    }

    class RetrieveFeedTask extends AsyncTask<String, Void, Bitmap> {
        private Exception exception;
        protected Bitmap doInBackground(String...urll) {
            try {
                final Bitmap[] myBitmap = {null};
                URL url = new URL(urll[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setDoInput(true);
                connection.connect();
                InputStream input = connection.getInputStream();
                myBitmap[0] = BitmapFactory.decodeStream(input);
                return myBitmap[0];
            } catch (Exception e) {
                this.exception = e;
                return null;
            }
        }

        protected void onPostExecute(Bitmap feed) {
            image.setImageBitmap(feed);
        }
    }
}
