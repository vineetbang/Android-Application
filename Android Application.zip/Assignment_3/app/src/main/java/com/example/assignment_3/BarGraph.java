package com.example.assignment_3;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
//import android.support.v7.app.ActionBarActivity;

import androidx.appcompat.app.AppCompatActivity;

import com.example.assignment_3.networkconnection.RestClient;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;

public class BarGraph extends AppCompatActivity {
    Spinner spin;
    Button display;
    BarChart graph;
    BarData data;
    RestClient client;
    SharedPreferences sh;
    String user[];
    String nm="";
    XAxis xplane;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bar);
        spin = (Spinner)findViewById(R.id.year);
         graph = (BarChart) findViewById(R.id.barGraph);
         display=(Button)findViewById(R.id.display_bar);
         client = new RestClient();
         user = new String[20];
         sh = getSharedPreferences("SharedPrefName",
                 MODE_PRIVATE);
         nm = sh.getString("Firstnm","");
         display.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 task addStudentTask = new task();
                 addStudentTask.execute(spin.getSelectedItem().toString());
             }
         });
    }
    
    private class task extends AsyncTask<String, Void, String[]> {
        @Override
        protected String[] doInBackground(String... params) {
            return client.userName(nm);
        }
        @Override
        protected void onPostExecute(String[] result) {
            user = result;
            b_count b_count=new b_count();
            b_count.execute(user);
        }
    }

    private class b_count extends AsyncTask<String, Void, ArrayList<bar_sum>>{
        @Override
        protected ArrayList<bar_sum> doInBackground(String... params) {
            return client.getBarCount(Integer.parseInt(params[5]),spin.getSelectedItem().toString()) ;
        }
        @Override
        protected void onPostExecute(ArrayList<bar_sum> result) {
            data = new BarData(data(result));
            graph.setData(data);
            xplane=graph.getXAxis();
            graph.animateXY(2000, 2000);
            graph.invalidate();
        }
    }
    
    private ArrayList data(ArrayList<bar_sum> r) {
        ArrayList sets = null;
        String plane="";
        ArrayList vset = new ArrayList();
        int temper = 0;
        for(int i=0;i<r.size();i++){
            bar_sum barg = r.get(i);
            if(barg.getMonths().compareTo("January")==0){
                temper=1;
            } else if(barg.getMonths().compareTo("February")==0){
                temper=2;
            }
            else if(barg.getMonths().compareTo("March")==0){
                temper=3;
            }
            else if(barg.getMonths().compareTo("April")==0){
                temper=4;
            }
            else if(barg.getMonths().compareTo("May")==0){
                temper=5;
            }
            else if(barg.getMonths().compareTo("June")==0){
                temper=6;
            }
            else if(barg.getMonths().compareTo("July")==0){
                temper=7;
            }
            else if(barg.getMonths().compareTo("August")==0){
                temper=8;
            }
            else if(barg.getMonths().compareTo("September")==0){
                temper=9;
            }
            else if(barg.getMonths().compareTo("October")==0){
                temper=10;
            }
            else if(barg.getMonths().compareTo("November")==0){
                temper=11;
            }
            else if(barg.getMonths().compareTo("December")==0){
                temper=12;
            }

            if(temper==1){
                plane+="Jan, ";
            } else if(temper==2){
                plane+="Feb, ";
            } else
            if(temper==3){
                plane+="Mar, ";
            } else
            if(temper==4){
                plane+="Apr, ";
            } else
            if(temper==5){
                plane+="May, ";
            } else
            if(temper==6){
                plane+="Jun, ";
            } else
            if(temper==7){
                plane+="Jul, ";
            } else
            if(temper==8){
                plane+="Aug, ";
            } else
            if(temper==9){
                plane+="Sep, ";
            } else
            if(temper==10){
                plane+="Oct, ";
            } else
            if(temper==11){
                plane+="Nov, ";
            }else if(temper==12){
                plane+="Dec";
            }

            BarEntry v1e1 = new BarEntry(temper, barg.getCount());
            vset.add(v1e1);
        }


        BarDataSet barDataSet1 = new BarDataSet(vset, "Movie Counter");
          barDataSet1.setLabel(plane);
        barDataSet1.setColors(ColorTemplate.COLORFUL_COLORS);
        sets = new ArrayList();
        sets.add(barDataSet1);
        return sets;
    }
}