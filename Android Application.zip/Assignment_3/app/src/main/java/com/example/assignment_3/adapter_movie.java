package com.example.assignment_3;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class adapter_movie extends ArrayAdapter<movies> {


        private Context con;
        private ArrayList<movies> mlist = new ArrayList<>();

    public adapter_movie(@NonNull Context context, @SuppressLint("SupportAnnotationUsage") @LayoutRes ArrayList<movies> list) {
        super(context, 0 ,list);
        con = context;
        mlist = list;
    }

    @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            View listItem = convertView;
            if (listItem == null)
                listItem = LayoutInflater.from(con).inflate(R.layout.movie_list, parent, false);
// movies are set here with text view and others
            movies currentMovies = mlist.get(position);
            TextView name = (TextView) listItem.findViewById(R.id.name);
            name.setText(currentMovies.getmovie());
            TextView releaseDate = (TextView)listItem.findViewById(R.id.releaseDate);
            releaseDate.setText(currentMovies.getmRDate());
            TextView rating = (TextView) listItem.findViewById(R.id.rating);
                rating.setText(currentMovies.getrating());
            return listItem;
        }
    }
