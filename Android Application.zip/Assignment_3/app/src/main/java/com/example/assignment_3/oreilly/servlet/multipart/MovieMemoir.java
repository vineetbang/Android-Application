package com.example.assignment_3.oreilly.servlet.multipart;

public class MovieMemoir {

    private String movieName,comment, dateWatch,movieReleaseDate,ratingScore,postcode,timeWatch;

    public MovieMemoir(String movieName,String comment, String dateWatch,String movieReleaseDate,String ratingScore,String postcode,String timeWatch)
    {
        this.movieName = movieName;
        this.comment= comment;
        this.dateWatch = dateWatch;
        this.movieReleaseDate = movieReleaseDate;
        this.ratingScore = ratingScore;
        this.postcode = postcode;
        this.timeWatch=timeWatch;
    }

    public String getComment() {
        return comment;
    }

    public String getDateWatch() {
        return dateWatch;
    }

    public String getMovieName() {
        return movieName;
    }

    public String getMovieReleaseDate() {
        return movieReleaseDate;
    }

    public String getPostcode() {
        return postcode;
    }

    public String getRatingScore() {
        return ratingScore;
    }

    public String getTimeWatch() {
        return timeWatch;
    }
}
