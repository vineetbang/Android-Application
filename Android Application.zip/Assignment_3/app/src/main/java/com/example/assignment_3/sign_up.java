package com.example.assignment_3;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.assignment_3.networkconnection.RestClient;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class sign_up extends AppCompatActivity {
    EditText fname, lname, date, address, post, email, pass;
    Spinner state;
    RestClient restClient;
    Button signup;
    String firstname ="", lastname = "", dd= "", addrs = "", posts = "", emailc = "",passc = "", states = "",gg ="";
    private RadioGroup radioGroup;
    private RadioButton gender;
    final Calendar myCalendar = Calendar.getInstance();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        restClient = new RestClient();
        setContentView(R.layout.activity_sign_up);
        fname = (EditText)findViewById(R.id.FirstName);
        lname = (EditText)findViewById(R.id.lastname);
        date = (EditText)findViewById(R.id.date);
        address = (EditText)findViewById(R.id.Address);
        post = (EditText)findViewById(R.id.post);
        email = (EditText)findViewById(R.id.email);
        pass = (EditText)findViewById(R.id.pass);
        state = (Spinner)findViewById(R.id.state);
        signup = (Button)findViewById(R.id.sign);
        addListenerOnButton();
        date.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub'

                new DatePickerDialog(sign_up.this, date2, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
    }
    DatePickerDialog.OnDateSetListener date2 = new DatePickerDialog.OnDateSetListener() {

        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear,
                              int dayOfMonth) {
            // TODO Auto-generated method stub
            myCalendar.set(Calendar.YEAR, year);
            myCalendar.set(Calendar.MONTH, monthOfYear);
            myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            updateLabel();
        }

    };
    private void updateLabel() {
        String myFormat = "yyyy-MM-dd"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        date.setText(sdf.format(myCalendar.getTime()));
    }

    public void addListenerOnButton() {

        radioGroup = (RadioGroup) findViewById(R.id.radio);
        signup.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // get selected radio button from radioGroup
                int selectedId = radioGroup.getCheckedRadioButtonId();

                // find the radiobutton by returned id
                gender = (RadioButton) findViewById(selectedId);
                gg = gender.getText().toString();
                firstname = fname.getText().toString();
                lastname = lname.getText().toString();
                dd = date.getText().toString();
                addrs = address.getText().toString();
                posts = post.getText().toString();
                emailc = email.getText().toString();
                passc = pass.getText().toString();
                states = state.getSelectedItem().toString();
                if (emailc!=null) {
                    String[] details = new String[12];
                    details[0] = passc;
                    details[1] = addrs;
                    details[2] = states;
                    details[3] = dd + "T00:00:00+11:00";
                    details[4] = firstname;
                    details[5] = gg;
                    details[6] = "10";  //  To be done by shared prefrences
                    details[7] = posts;
                    details[8] = lastname;
                    details[9] = "2020-05-05T00:00:00+11:00";
                    details[10] = "10";
                    details[11] = emailc;
                    int flag = 0;
                    for(int i=0;i<12;i++) {
                        if (details[i].compareTo("")==0)
                        {
                            Toast.makeText(sign_up.this,"Empty data not allowed",Toast.LENGTH_SHORT).show();
                            flag =1;

                            Intent intent = getIntent();
                            finish();
                            startActivity(intent);
                        }

                    }
                    if(flag==0) {
                        AddStudentTask addStudentTask = new AddStudentTask();
                        addStudentTask.execute(details);
                    }
                }



            }

        });

    }

    private class AddStudentTask extends AsyncTask<String, Void, String> {
        @Override
    protected String doInBackground(String... params) {

        return restClient.addData(params) ;
    }
        @Override
        protected void onPostExecute(String result) {

            Toast.makeText(sign_up.this,"Data Added"+result,Toast.LENGTH_SHORT).show();
            }
    }
}
