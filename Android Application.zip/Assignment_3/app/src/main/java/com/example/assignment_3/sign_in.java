package com.example.assignment_3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.assignment_3.networkconnection.RestClient;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import okhttp3.ResponseBody;

public class sign_in extends AppCompatActivity {
    Button signin,signup;
    TextView welcomeText;
    EditText email,password;
    RestClient restClient =null;
    //UserService userService;
    ResponseBody res;
    String emailCheck;
    String passCheck;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        restClient = new RestClient();
        email = (EditText)findViewById(R.id.editText);
        password = (EditText)findViewById(R.id.editText2);
        welcomeText = (TextView)findViewById(R.id.textView);
        signin = (Button)findViewById(R.id.button);
        signup = (Button)findViewById(R.id.button2);




        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent;
                intent = new Intent(sign_in.this, sign_up.class);
                startActivity(intent);
            }
        });

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


              //  Log.d("em",emailCheck);
                CoursesAsyncTask getAllData = new CoursesAsyncTask();
                getAllData.execute();

            }
        });

    }
    private class CoursesAsyncTask extends AsyncTask<Void, Void, Integer> {
        @Override
    protected Integer doInBackground(Void... params) {
            emailCheck = email.getText().toString();
            passCheck = password.getText().toString();

            String passwordToHash = passCheck;
            String generatedPassword = null;
            try {
                // Create MessageDigest instance for MD5
                MessageDigest md = MessageDigest.getInstance("MD5");
                //Add password bytes to digest
                md.update(passwordToHash.getBytes());
                //Get the hash's bytes
                byte[] bytes = md.digest();
                //This bytes[] has bytes in decimal format;
                //Convert it to hexadecimal format
                StringBuilder sb = new StringBuilder();
                for(int i=0; i< bytes.length ;i++)
                {
                    sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
                }
                //Get complete hashed password in hex format
                generatedPassword = sb.toString();
            }
            catch (NoSuchAlgorithmException e)
            {
                e.printStackTrace();
            }

        return restClient.findEmailAndPass(emailCheck, generatedPassword);
    }
        @Override
        protected void onPostExecute(Integer students) {


            passCheck = password.getText().toString();
            if(students==1) {
                Intent intent;
                intent = new Intent(sign_in.this, home.class);
                intent.putExtra("emails",emailCheck);

                startActivity(intent);
            } else {
                Toast.makeText(sign_in.this,"Login Unsuccessfull",Toast.LENGTH_SHORT).show();
            }
            }

        }

}






