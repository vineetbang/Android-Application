package com.example.assignment_3;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;

import com.example.assignment_3.fragment.home_fragment;
import com.example.assignment_3.fragment.Map;
import com.example.assignment_3.fragment.Movie_Memoir;
import com.example.assignment_3.fragment.Movie_Search;
import com.example.assignment_3.fragment.Report;
import com.example.assignment_3.fragment.Watchlist;
import com.google.android.material.navigation.NavigationView;

public class home extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout draw;
    private ActionBarDrawerToggle tog;
    private NavigationView nav;
    String place;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        draw = findViewById(R.id.drawer_layout);
        nav = findViewById(R.id.nv);
        tog = new ActionBarDrawerToggle(this, draw,R.string.Open,R.string.Close);
        draw.addDrawerListener(tog);
        tog.syncState();

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        nav.setNavigationItemSelectedListener(this);
        replace(new home_fragment());
        Bundle bundle1 = getIntent().getExtras();
        Bundle bundle = new Bundle();
        place = bundle1.getString("emails");
        bundle.putString("emails",bundle1.getString("emails"));
        home_fragment home_fragment = new home_fragment();
        home_fragment.setArguments(bundle);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.moviesearch:
                replace(new Movie_Search());
                break;
            case R.id.moviememoir:
                replace(new Movie_Memoir());
                break;
            case R.id.watchlist:
                replace(new Watchlist());
                break;
            case R.id.Reports:
                replace(new Report());
                break;
            case R.id.Maps:
                replace(new Map());
                break;
        }
        draw.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        if (tog.onOptionsItemSelected(item))
        return true;
        return super.onOptionsItemSelected(item);
    }

    private void replace(Fragment newer) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.content_frame, newer);
        fragmentTransaction.commit();
    }
    public String getDate() {
        return place ;
    }
}
