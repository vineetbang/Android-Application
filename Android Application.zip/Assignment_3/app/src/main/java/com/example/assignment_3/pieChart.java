package com.example.assignment_3;

import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.assignment_3.networkconnection.RestClient;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import lecho.lib.hellocharts.model.PieChartData;
import lecho.lib.hellocharts.model.SliceValue;
import lecho.lib.hellocharts.view.PieChartView;

public class pieChart extends AppCompatActivity {
    PieChartView p_chart;
    RestClient client;
    SharedPreferences share;
    String temp="";
    String user[];
    ArrayList<pie_sum> chart;
    final Calendar cal = Calendar.getInstance();
    EditText start,end;
    Button show;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.piechart);
        client=new RestClient();
        p_chart = findViewById(R.id.chart);
        start=(EditText)findViewById(R.id.start);
        end=(EditText)findViewById(R.id.end);
        show=(Button)findViewById(R.id.display);
        share = getSharedPreferences("SharedPrefName",
                MODE_PRIVATE);
        temp = share.getString("Firsttemp","");
        user = new String[20];
        start.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                new DatePickerDialog(pieChart.this, date2, cal
                        .get(Calendar.YEAR), cal.get(Calendar.MONTH),
                        cal.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
        end.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(pieChart.this, date3, cal
                        .get(Calendar.YEAR), cal.get(Calendar.MONTH),
                        cal.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
        show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                task addStudentTask = new task();
                addStudentTask.execute(temp);
            }
        });
    }

    private class task extends AsyncTask<String, Void, String[]> {
        @Override
        protected String[] doInBackground(String... params) {
            return client.userName(temp);
        }
        @Override
        protected void onPostExecute(String[] result) {
            user = result;
            countpie countpie = new countpie();
            countpie.execute(user);
        }
    }

    private class countpie extends AsyncTask<String, Void, ArrayList<pie_sum>>{
        @Override
        protected ArrayList<pie_sum> doInBackground(String... params) {

            return client.getPieCount(Integer.parseInt(params[5]),start.getText().toString(),end.getText().toString()) ;
        }
        @Override
        protected void onPostExecute(ArrayList<pie_sum> result) {
            int percent[] = new int[20];
            List pieData = new ArrayList<>();
            chart = result;
            int totalc = 0;
            for (int i = 0; i < chart.size(); i++) {
                pie_sum charter = chart.get(i);
                totalc += charter.getCount();
            }
            ArrayList<Integer> lister = new ArrayList<>();
            lister.add(Color.BLACK);
            lister.add(Color.GREEN);
            lister.add(Color.BLUE);
            lister.add(Color.RED);
            lister.add(Color.YELLOW);

            for (int i = 0; i < chart.size(); i++) {
                pie_sum charter = chart.get(i);
                pieData.add(new SliceValue(charter.getCount() * 10, lister.get(i)).setLabel("" + charter.getPostcode() + " :" + (Float.parseFloat("" + (charter.getCount() * 100) / totalc) + "%")));
            }
            pie_sum charter = chart.get(0);
            PieChartData pieChartData = new PieChartData(pieData);
            pieChartData.setHasLabels(true).setValueLabelTextSize(14);
            pieChartData.setHasCenterCircle(true).setCenterText1("Movies Watched").setCenterText1FontSize(20).setCenterText1Color(Color.parseColor("#0097A7"));
            p_chart.setPieChartData(pieChartData);
        }
    }

    DatePickerDialog.OnDateSetListener date2 = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear,
                              int dayOfMonth) {
            // TODO Auto-generated method stub
            cal.set(Calendar.YEAR, year);
            cal.set(Calendar.MONTH, monthOfYear);
            cal.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            update();
        }
    };
    DatePickerDialog.OnDateSetListener date3 = new DatePickerDialog.OnDateSetListener() {

        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear,
                              int dayOfMonth) {
            // TODO Auto-generated method stub
            cal.set(Calendar.YEAR, year);
            cal.set(Calendar.MONTH, monthOfYear);
            cal.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            update1();
        }
    };
    private void update() {
        String myFormat = "yyyy-MM-dd"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        start.setText(sdf.format(cal.getTime()));
    }
    private void update1() {
        String myFormat = "yyyy-MM-dd"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        end.setText(sdf.format(cal.getTime()));
    }
}
